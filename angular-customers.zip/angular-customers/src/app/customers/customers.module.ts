import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpModule } from '@angular/http';
import { InMemoryWebApiModule } from 'angular-in-memory-web-api';


import { CustomerInMemoryDataService } from './customer-in-memory-data.service';
import { CustomersRoutingModule } from './customers-routing.module';
import { CustomersListComponent } from './customers-list/customers-list.component';
import { CustomerDetailsComponent } from './customer-details/customer-details.component';
import { CustomerEditComponent } from './customer-edit/customer-edit.component';
import { CustomerCreateComponent } from './customer-create/customer-create.component';

@NgModule({
  imports: [
    CommonModule,
    HttpModule,
    InMemoryWebApiModule.forRoot(CustomerInMemoryDataService),
    CustomersRoutingModule
  ],
  declarations: [CustomersListComponent, CustomerDetailsComponent, CustomerEditComponent, CustomerCreateComponent]
})
export class CustomersModule { }
