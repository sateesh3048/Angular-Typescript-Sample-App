import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-customer-create',
  templateUrl: './customer-create.component.html',
  styleUrls: ['./customer-create.component.css']
})
export class CustomerCreateComponent implements OnInit {

  constructor( private customerService: CustomerService) { }

  ngOnInit() {
  }

  addCustomer(name: string){
    this.customerService.addCustomer(name).then((customer) => {
      
    })
  }

}
