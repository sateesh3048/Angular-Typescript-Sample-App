import { InMemoryDbService } from 'angular-in-memory-web-api';
export class CustomerInMemoryDataService implements InMemoryDbService {
  createDb() {
    const customers = [
      { id: 1, name: "Santosh"},
      { id: 2, name: "Narendra"},
      { id: 3, name: "Suresh"},
      { id: 4, name: "Jhonson"},
      { id: 5, name: "Gita"},
      { id: 6, name: "Lohita"},
      { id: 7, name: "Yashmita"},
      { id: 8, name: "Lakshmi"},
      { id: 9, name: "Ani"},
      { id: 10, name: "Bablu"}
    ]
    return {customers};
  }
}