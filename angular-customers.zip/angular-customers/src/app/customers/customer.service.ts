import { Injectable } from '@angular/core';
import { Customer } from './customer';
import { Headers, Http } from '@angular/http';
import 'rxjs/add/operator/toPromise'
@Injectable()
export class CustomerService {
  private customersUrl = "api/customers";
  private headers = new Headers({'Content-Type': 'application/json'});
  constructor(private http: Http) { }

  allCustomers(): Promise<Customer[]> {
    return this.http.get(this.customersUrl)
      .toPromise()
      .then(response => response.json().data as Customer[])
      .catch(this.handleError);
  }

  addCustomer(name: string): Promise<Customer> {
    const customer = JSON.stringify({name: name});
    return this.http.post(this.customersUrl, customer, {headers: this.headers})
             .toPromise()
             .then(response => response.json().data as Customer)
             .catch(this.handleError);
  }

  handleError(error: any){
    console.log("An error occured", error);
    return Promise.reject(error.message || error);
  }

}
