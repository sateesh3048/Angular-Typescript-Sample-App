import { AngularCustomersPage } from './app.po';

describe('angular-customers App', () => {
  let page: AngularCustomersPage;

  beforeEach(() => {
    page = new AngularCustomersPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!!');
  });
});
