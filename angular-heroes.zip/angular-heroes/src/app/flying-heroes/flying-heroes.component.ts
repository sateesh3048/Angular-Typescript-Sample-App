import { Component } from '@angular/core';
import { Flyer } from '../flyer';

@Component({
  selector: 'app-flying-heroes',
  templateUrl: './flying-heroes.component.html',
  styleUrls: ['./flying-heroes.component.css']
})
export class FlyingHeroesComponent {
  heroes: Flyer[] = [];
  canFly = true;
  constructor() { this.reset(); }


  addHero(name: string){
    console.log(name);
    name = name.trim();
    if(!name) {return;}
    const hero: Flyer = {name: name, canFly: this.canFly}
    this.heroes.push(hero);
  }

  reset() {
    this.heroes = [{
      name: 'Raghu',
      canFly: false
    },
    {
      name: 'Rama',
      canFly: true
    },
    {
      name: 'Test2',
      canFly: true
    }];
  }
}
