import { FlyingHeroesPipe } from './flying-heroes.pipe';

describe('FlyingHeroesPipe', () => {
  it('create an instance', () => {
    const pipe = new FlyingHeroesPipe();
    expect(pipe).toBeTruthy();
  });
});
