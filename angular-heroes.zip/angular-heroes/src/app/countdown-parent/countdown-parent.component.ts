import { Component, OnInit } from '@angular/core';
// import { CountdownTimerComponent } from '../countdown-timer/countdown-timer.component';
@Component({
  selector: 'app-countdown-parent',
  template: `
    <h3>Countdown to Liftoff (via loca variable)</h3>
    <button (click)="timer.start()">Start</button>
    <button (click)="timer.stop()">Stop</button>
    <div class="seconds">{{timer.seconds}}</div>
    <app-countdown-timer #timer></app-countdown-timer>`,
  styleUrls: ['./countdown-parent.component.css']
})
export class CountdownParentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
