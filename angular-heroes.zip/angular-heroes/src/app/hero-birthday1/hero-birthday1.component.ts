import { Component } from '@angular/core';

@Component({
  selector: 'app-hero-birthday1',
  template: `<p>The hero's birthday is {{birthday | date: "MM/dd/yy"}}</p>`,
  styleUrls: ['./hero-birthday1.component.css']
})
export class HeroBirthday1Component {
  birthday = new Date(1986, 5, 10);
}
