import { Component } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Subscriber } from 'rxjs/Subscriber';

@Component({
  selector: 'app-current-time',
  template: `<div><code>Observable|async</code>Time: {{time }}</div>`,
  styleUrls: ['./current-time.component.css']
})
export class CurrentTimeComponent {

  time = 'test';
  /*new Observable<string>((observer: Subscriber<string>) => {
    setInterval(() => observer.next(new Date().toString()), 1000);
  })*/

  constructor() { }



}
