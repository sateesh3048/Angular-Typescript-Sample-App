import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent  {
  isSpecial = true;
  a = 10;
  b = 20;
  warnUser = true;
  canSave = true;
  isUnChanged = true;
  name: string;

  person = { name: 'Sateesh', age: 31, address: 'Hyderabad', emotion: "Happy" };
  persons = [{name: 'Krishna Babu', age: 35, address: 'SR Puram', emotion: "Very Happy"} , {name: 'Anji Babu', age: 33, address: 'junction', emotion: "Super Happy"} , this.person]
  
  currentClasses = {
    'saveable': this.canSave,
    'modifiable': this.isUnChanged,
    'special': this.isSpecial
  }  

  currentStyles = {
    'font-style': this.canSave ? 'italic' : 'normal',
    'font-weight': this.isUnChanged ? 'bold' : 'normal',
    'font-size': this.isSpecial? '24px' : '12px'
  };

  languages: string[] = [
    'ruby',
    'rails',
    'html',
    'css',
    'javascript',
    'jquery'
  ];

  emotion = 'good';

  constructor() {};
  
  sayRock(msg: string){
    alert(`Welcome to ${msg}!`);
  }


  setUppercaseName(name: string) {
    console.log(name);
    console.log(name.toUpperCase())
    this.name = name.toUpperCase();

  }

  phoneCall(number:string){
    console.log(`my phone number is ${number}`)
  }





}



