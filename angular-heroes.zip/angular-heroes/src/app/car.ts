export class Engine{};

export class Tires {};
export class Car{
  constructor(public engine: Engine, public tyres: Tires){
    console.log('Engine testing');
    console.log(engine);
    console.log('Tyres testing');
    console.log(tyres);
  }
}

