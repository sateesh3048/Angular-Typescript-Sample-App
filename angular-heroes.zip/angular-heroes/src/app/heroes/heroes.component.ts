import { Component, OnInit } from '@angular/core';
import { Hero } from '../hero';
import { HeroService } from '../hero.service';
import { Router } from '@angular/router';
import { Car } from '../car';
import { Engine } from '../car';
import { Tires } from '../car';


@Component({
  selector: 'app-heroes',
  templateUrl: './heroes.component.html',
  styleUrls: ['./heroes.component.css'],
  providers: [HeroService]
})


export class HeroesComponent implements OnInit {
  heroes: Hero[];
  selectedHero: Hero;


  constructor(private heroService: HeroService, private router: Router) {
    const car: Car = new Car(new Engine(), new Tires());
    console.log('Car Object');
    console.log(car);

  };

  add(name: string):void{
    name = name.trim();
    if(!name){ return; }
    this.heroService.create(name)
                    .then(hero => {
                      this.heroes.push(hero);
                      this.selectedHero =  null;
                    });
  };

  delete(hero: Hero):void{
    this.heroService.destroy(hero).then(() => {
      this.heroes = this.heroes.filter(h => h != hero);
      if (this.selectedHero === hero) { this.selectedHero = null; }
    })
  }

  getHeroes() {
    this.heroService.getHeroes().then((heroes) => this.heroes = heroes);
  };

  ngOnInit() {
    this.getHeroes();
  };

  onSelect(hero: Hero){
    this.selectedHero = hero;
  }

  gotoDetail(): void {
    this.router.navigate(['/detail', this.selectedHero.id]);
  }
}
