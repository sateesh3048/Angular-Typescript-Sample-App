export interface Flyer {
  name: string,
  canFly: boolean
}
