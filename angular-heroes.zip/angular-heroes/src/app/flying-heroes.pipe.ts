import { Pipe, PipeTransform } from '@angular/core';
import { Flyer } from './flyer';

@Pipe({
  name: 'flyingHeroes'
})
export class FlyingHeroesPipe implements PipeTransform {

  transform(allHeroes: Flyer[]): any {
    return allHeroes.filter(hero => hero.canFly);
  }

}
