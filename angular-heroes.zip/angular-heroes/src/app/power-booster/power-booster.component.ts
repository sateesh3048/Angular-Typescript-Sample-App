import { Component } from '@angular/core';

@Component({
  selector: 'app-power-booster',
  template: `<h2>Power Booster</h2>
    <div>Normal Power: <input [(ngModel)] = "power" /></div>
    <div> Boost Factor: <input [(ngModel)] = "factor" /> </div>
    <p>Super power boost: {{power|exponentialStrength: factor}}</p>
  `,
  styleUrls: ['./power-booster.component.css']
})
export class PowerBoosterComponent{
  power = 5;
  factor = 1; 
}
