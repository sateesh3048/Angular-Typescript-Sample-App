import { Injectable } from '@angular/core';
import { UserInfo } from '../models/user-info';

@Injectable()
export class LoginService {

  constructor() { }

  authenitcate(uname, password){
    console.log(`Username: ${uname} with password ${password}`)
    return new UserInfo("Sateesh K",uname, true); 
  }
}
