import { Injectable } from '@angular/core';
import { UserInfo } from '../models/user-info';

@Injectable()
export class AppDataService {
  //name:string;
  //uname:string;
  //isValidUser:boolean = false;
  userInfo:UserInfo = new UserInfo(undefined, undefined, false);

  constructor() { }
  resetAll(){
    this.userInfo = new UserInfo(undefined, undefined, false);
  }
}
