import { Component, OnInit } from '@angular/core';
import { LoginService } from '../services/login.service';
import { AppDataService } from '../services/app-data.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  uname: string = "sai" ;
  password: string;


  constructor(private loginService:LoginService, private appData: AppDataService) { }

  ngOnInit() {
  }

  onLoginClick(event) {
    //console.log(this.uname + this.password);
    var result = this.loginService.authenitcate(this.uname, this.password);
    this.appData.userInfo = result;

  }

}
