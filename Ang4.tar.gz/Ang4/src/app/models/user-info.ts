export class UserInfo {
  name:string;
  uname:string;
  isValidUser:boolean = false;
  

  constructor(name:string, uname:string, isValidUser:boolean){
    this.name=name;
    this.uname=uname;
    this.isValidUser=isValidUser;
  }
}
